/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.ejercicio__1;

/**
 *
 * @author Usuario
 */
public class EJERCICIO__1 {

    public static void main(String[] args) {
        // a) Crear dos instancias de Caja con tipos diferentes
        Caja<String> cajaDeTexto = new Caja<>();
        Caja<Integer> cajaDeNumero = new Caja<>();
        
        // b) Guardar datos en las cajas
        cajaDeTexto.guardar("Hola Mundo");
        cajaDeNumero.guardar(42);
        
        // c) Mostrar el contenido de las cajas
        cajaDeTexto.mostrarContenido();
        cajaDeNumero.mostrarContenido();
        
        String texto = cajaDeTexto.obtener();
        int numero = cajaDeNumero.obtener();
        System.out.println("\nValores obtenidos:");
        System.out.println("Texto: " + texto);
        System.out.println("Numero: " + numero);
    }
}
