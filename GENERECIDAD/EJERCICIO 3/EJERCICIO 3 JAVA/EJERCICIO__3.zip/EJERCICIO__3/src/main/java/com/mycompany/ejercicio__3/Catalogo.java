/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ejercicio__3;

/**
 *
 * @author Usuario
 */
import java.util.ArrayList;
import java.util.List;

public class Catalogo<T> {
    private List<T> elementos;
    
    public Catalogo() {
        this.elementos = new ArrayList<>();
    }
    
    // Método para agregar elementos
    public void agregar(T elemento) {
        elementos.add(elemento);
        System.out.println("Elemento agregado: " + elemento.toString());
    }
    
    // Método para buscar elementos (por criterio personalizado)
    public T buscar(java.util.function.Predicate<T> criterio) {
        for (T elemento : elementos) {
            if (criterio.test(elemento)) {
                return elemento;
            }
        }
        return null;
    }
    
    // Método para mostrar todos los elementos
    public void mostrarTodos() {
        System.out.println("\n--- Contenido del Catalogo ---");
        elementos.forEach(System.out::println);
    }
}