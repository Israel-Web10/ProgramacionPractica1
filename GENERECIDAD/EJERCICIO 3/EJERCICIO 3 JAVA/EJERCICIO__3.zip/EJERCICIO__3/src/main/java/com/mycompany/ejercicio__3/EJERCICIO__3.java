/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.ejercicio__3;

/**
 *
 * @author Usuario
 */
public class EJERCICIO__3 {

    public static void main(String[] args) {
        
        // a) Catálogo de Libros
        Catalogo<Libro> catalogoLibros = new Catalogo<>();
        catalogoLibros.agregar(new Libro("Cien anos de soledad", "Garcia Marquez"));
        catalogoLibros.agregar(new Libro("1984", "George Orwell"));
        
        // Buscar libro por título
        Libro libroEncontrado = catalogoLibros.buscar(l -> l.getTitulo().equals("1984"));
        System.out.println("\nLibro encontrado: " + libroEncontrado);
        
        // b) Catálogo de Productos
        Catalogo<Producto> catalogoProductos = new Catalogo<>();
        catalogoProductos.agregar(new Producto("Laptop", 999.99));
        catalogoProductos.agregar(new Producto("Mouse", 19.99));
        
        // Buscar producto por precio
        Producto productoEncontrado = catalogoProductos.buscar(p -> p.getPrecio() < 50);
        System.out.println("\nProducto economico: " + productoEncontrado);
        
        // c) Mostrar todos los elementos
        catalogoLibros.mostrarTodos();
        catalogoProductos.mostrarTodos();
    }
}
