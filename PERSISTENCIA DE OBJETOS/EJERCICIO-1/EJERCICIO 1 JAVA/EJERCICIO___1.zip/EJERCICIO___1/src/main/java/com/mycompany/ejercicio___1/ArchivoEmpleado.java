/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ejercicio___1;

/**
 *
 * @author Usuario
 */
import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class ArchivoEmpleado {
    private String nomA;
    
    public ArchivoEmpleado(String nomA) {
        this.nomA = nomA;
    }
    
    // a) Crear archivo si no existe
    public void crearArchivo() {
        try {
            File archivo = new File(nomA);
            if (archivo.createNewFile()) {
                System.out.println("Archivo creado: " + archivo.getName());
            }
        } catch (IOException e) {
            System.out.println("Error al crear archivo: " + e.getMessage());
        }
    }
    
    // a) Guardar empleado (serialización)
    public void guardarEmpleado(Empleado e) {
        try (ObjectOutputStream oos = new ObjectOutputStream(
             new FileOutputStream(nomA, true))) {
            oos.writeObject(e);
            System.out.println("Empleado guardado: " + e.getNombre());
        } catch (IOException ex) {
            System.out.println("Error al guardar: " + ex.getMessage());
        }
    }
    
    // b) Buscar empleado por nombre
    public Empleado buscaEmpleado(String nombre) {
        try (ObjectInputStream ois = new ObjectInputStream(
             new FileInputStream(nomA))) {
            while (true) {
                Empleado emp = (Empleado) ois.readObject();
                if (emp.getNombre().equalsIgnoreCase(nombre)) {
                    return emp;
                }
            }
        } catch (EOFException e) {
            System.out.println("Busqueda finalizada");
        } catch (IOException | ClassNotFoundException e) {
            System.out.println("Error en busqueda: " + e.getMessage());
        }
        return null;
    }
    
    // c) Buscar empleado con salario mayor
    public Empleado mayorSalario(float sueldo) {
        try (ObjectInputStream ois = new ObjectInputStream(
             new FileInputStream(nomA))) {
            while (true) {
                Empleado emp = (Empleado) ois.readObject();
                if (emp.getSalario() > sueldo) {
                    return emp;
                }
            }
        } catch (EOFException e) {
            System.out.println("Búsqueda finalizada");
        } catch (IOException | ClassNotFoundException e) {
            System.out.println("Error en búsqueda: " + e.getMessage());
        }
        return null;
    }
}