/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.ejercicio___1;

/**
 *
 * @author Usuario
 */
public class EJERCICIO___1 {

    public static void main(String[] args) {
        ArchivoEmpleado archivo = new ArchivoEmpleado("empleados.dat");
        archivo.crearArchivo();
        
        // a) Guardar empleados
        archivo.guardarEmpleado(new Empleado("Juan Perez", 35, 2500.50f));
        archivo.guardarEmpleado(new Empleado("Maria Lopez", 28, 3200.75f));
        archivo.guardarEmpleado(new Empleado("Carlos Gomez", 42, 1800.25f));
        
        // b) Buscar empleado
        System.out.println("\n--- Buscar 'Maria Lopez' ---");
        Empleado emp = archivo.buscaEmpleado("Maria Lopez");
        System.out.println(emp != null ? emp : "No encontrado");
        
        // c) Buscar salario > 2000
        System.out.println("\n--- Empleado con salario > $2000 ---");
        Empleado empSalario = archivo.mayorSalario(2000);
        System.out.println(empSalario != null ? empSalario : "No encontrado");
    }
}
