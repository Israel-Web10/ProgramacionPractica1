/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ejercicio___3;

/**
 *
 * @author Usuario
 */
import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class ArchivoCliente {
    private String nomA;
    
    public ArchivoCliente(String nomA) {
        this.nomA = nomA;
    }
    
    // a) Crear archivo si no existe
    public void crearArchivo() {
        try {
            File archivo = new File(nomA);
            if (archivo.createNewFile()) {
                System.out.println("Archivo creado: " + archivo.getName());
            }
        } catch (IOException e) {
            System.out.println("Error al crear archivo: " + e.getMessage());
        }
    }
    
    // a) Guardar cliente (serialización)
    public void guardaCliente(Cliente c) {
        try (ObjectOutputStream oos = new ObjectOutputStream(
             new FileOutputStream(nomA, true))) {
            oos.writeObject(c);
            System.out.println("Cliente guardado: " + c.getNombre());
        } catch (IOException ex) {
            System.out.println("Error al guardar: " + ex.getMessage());
        }
    }
    
    // b) Buscar cliente por ID
    public Cliente buscarCliente(int id) {
        try (ObjectInputStream ois = new ObjectInputStream(
             new FileInputStream(nomA))) {
            while (true) {
                Cliente cli = (Cliente) ois.readObject();
                if (cli.getId() == id) {
                    return cli;
                }
            }
        } catch (EOFException e) {
            System.out.println("Busqueda finalizada");
        } catch (IOException | ClassNotFoundException e) {
            System.out.println("Error en busqueda: " + e.getMessage());
        }
        return null;
    }
    
    // c) Buscar cliente por teléfono
    public Cliente buscarCelularCliente(int telefono) {
        try (ObjectInputStream ois = new ObjectInputStream(
             new FileInputStream(nomA))) {
            while (true) {
                Cliente cli = (Cliente) ois.readObject();
                if (cli.getTelefono() == telefono) {
                    return cli;
                }
            }
        } catch (EOFException e) {
            System.out.println("Busqueda finalizada");
        } catch (IOException | ClassNotFoundException e) {
            System.out.println("Error en busqueda: " + e.getMessage());
        }
        return null;
    }
}