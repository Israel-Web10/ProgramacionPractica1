/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.ejercicio___3;

/**
 *
 * @author Usuario
 */
public class EJERCICIO___3 {

    public static void main(String[] args) {
        ArchivoCliente archivo = new ArchivoCliente("clientes.dat");
        archivo.crearArchivo();
        
        // a) Guardar clientes
        archivo.guardaCliente(new Cliente(1, "Ana Perez", 5551234));
        archivo.guardaCliente(new Cliente(2, "Luis Gomez", 5555678));
        archivo.guardaCliente(new Cliente(3, "Carlos Ruiz", 5559012));
        
        // b) Buscar por ID
        System.out.println("\n--- Buscar ID 2 ---");
        Cliente cliId = archivo.buscarCliente(2);
        System.out.println(cliId != null ? cliId : "No encontrado");
        
        // c) Buscar por teléfono
        System.out.println("\n--- Buscar telefono 5559012 ---");
        Cliente cliTel = archivo.buscarCelularCliente(5559012);
        System.out.println(cliTel != null ? cliTel : "No encontrado");
    }
}
